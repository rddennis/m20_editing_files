ADVANCED VIM TEAM TOURNAMENT
============================

Folders
-------
originals/ contains clean challenge files.
targets/ contains the correct transformation result.
templates/ contains the team runbook.
work/ contains team copies.

Do not edit originals or targets.
Make all changes in work.

